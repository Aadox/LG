package fr.leomelki.loupgarou.events;

import fr.leomelki.loupgarou.classes.LGGame;

public class LGDayEndEvent extends LGEvent{
	public LGDayEndEvent(LGGame game) {
		super(game);
	}
}