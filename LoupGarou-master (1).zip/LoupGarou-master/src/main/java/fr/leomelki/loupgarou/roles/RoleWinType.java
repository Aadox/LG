package fr.leomelki.loupgarou.roles;

public enum RoleWinType {
	SEUL,
	VILLAGE,
	LOUP_GAROU,
	VAMPIRE,
	NONE;
}
