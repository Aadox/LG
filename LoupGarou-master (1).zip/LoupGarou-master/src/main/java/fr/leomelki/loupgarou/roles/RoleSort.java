package fr.leomelki.loupgarou.roles;

public enum RoleSort {
	ChienLoup,
	EnfantSauvage,
	Cupidon,
	Garde,
	Survivant,
	Voyante,
	Detective,
	Dictateur,
	Pretre,
	LoupGarou,
	LoupGarouNoir,
	GrandMechantLoup,
	LoupGarouBlanc,
	Assassin,
	Pyromane,
	ChasseurDeVampire,
	Vampire,
	Pirate,
	Bouffon,
	Sorciere,
	Corbeau;
}
