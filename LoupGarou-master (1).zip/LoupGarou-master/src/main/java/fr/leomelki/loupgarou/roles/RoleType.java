package fr.leomelki.loupgarou.roles;

public enum RoleType {
	VILLAGER,
	LOUP_GAROU,
	VAMPIRE,
	NEUTRAL;
}
